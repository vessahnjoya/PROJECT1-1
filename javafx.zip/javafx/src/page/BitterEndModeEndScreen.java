package page;

public class BitterEndModeEndScreen extends EndScreenBase {

    public BitterEndModeEndScreen() {
        this.titleText = "To the Bitter End";
        this.messageText = "You did not finish coloring the graph :(";
    }
}
