package page;

public class IChangedMyMindModeEndScreen extends EndScreenBase{

    public IChangedMyMindModeEndScreen() {

        this.titleText = "I Changed My Mind";
        this.messageText = "You did not finish coloring the graph :(";
    }

}
