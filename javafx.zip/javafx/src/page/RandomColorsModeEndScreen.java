package page;

public class RandomColorsModeEndScreen extends EndScreenBase {

    public RandomColorsModeEndScreen() {

        this.titleText = "Random Order";
        this.messageText = "You did not finish coloring the graph :(";
    }
}
